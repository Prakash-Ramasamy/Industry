# SupplyChain X v2.4 – Investigation API and data contract notes

These are proposed API contracts. They are not claims that the backend endpoints already exist.

## Core endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/investigations` | Create an investigation |
| GET | `/api/v1/investigations` | List/filter investigations |
| GET | `/api/v1/investigations/{id}` | Investigation summary and source links |
| POST | `/api/v1/investigations/{id}/identify-entities` | Extract, match and discover entities |
| GET | `/api/v1/investigations/{id}/entities` | Return suggested/confirmed entities |
| PUT | `/api/v1/investigations/{id}/entities` | Save user confirmation/exclusion |
| POST | `/api/v1/investigations/{id}/start` | Start the common workflow |
| GET | `/api/v1/investigations/{id}/status` | Workflow status and stage progress |
| GET | `/api/v1/investigations/{id}/workflow` | Stages and parallel lanes |
| GET | `/api/v1/investigations/{id}/agent-runs` | Agent execution summaries |
| GET | `/api/v1/investigations/{id}/recovery-plans` | Recovery options |
| POST | `/api/v1/investigations/{id}/scenario-preview` | Run a proactive scenario preview |

## Create request examples

### New disruption
```json
{
  "investigation_type": "NEW_DISRUPTION",
  "title": "Battery supplier outage",
  "description": "Supplier SUP-014 reports a 21-day production interruption.",
  "industry_id": "RENEWABLE_ENERGY",
  "severity": "HIGH",
  "provenance": "SYNTHETIC_DEMO"
}
```

### Existing order
```json
{
  "investigation_type": "EXISTING_ORDER",
  "title": "PO-2050 delivery delay investigation",
  "description": "Investigate the existing order for a route delay.",
  "source_records": [
    {"entity_type": "PURCHASE_ORDER", "entity_id": "PO-2050", "relationship_type": "PRIMARY_ORDER"}
  ]
}
```

### Existing shipment
```json
{
  "investigation_type": "EXISTING_SHIPMENT",
  "title": "Shipment route disruption",
  "source_records": [
    {"entity_type": "SHIPMENT", "entity_id": "SHIP-305", "relationship_type": "PRIMARY_SHIPMENT"}
  ]
}
```

### Proactive scenario
```json
{
  "investigation_type": "PROACTIVE_SCENARIO",
  "title": "Export restriction impact preview",
  "scenario": {
    "event_type": "EXPORT_CONTROL",
    "affected_country_codes": ["XXX"],
    "affected_hs_codes": ["850760"],
    "duration_days": 30,
    "severity": "HIGH"
  },
  "provenance": "SIMULATED"
}
```

`XXX` is a placeholder, not a real country code. API implementations must validate all submitted codes and identifiers against reference data.

## Important behavior

- Creating an investigation does not automatically start a workflow.
- Entity identification returns suggested matches; a user confirms or excludes them.
- A workflow starts only after required source records/entities are confirmed.
- Existing PO/shipment records are referenced, never copied into the investigation.
- Proactive scenario preview is labelled `SIMULATED / NOT EXECUTED`; it does not create an incident unless a user explicitly converts a confirmed real disruption into one.
- Use idempotency keys for create/start operations.
- All status transitions and approvals are enforced server-side.
