-- v2.4 post-migration seed updates.
-- The migration creates one investigation per existing incident and links the SCX-04 flagship.
-- This file is intentionally safe to re-run.
SET search_path TO scx, public;

-- Ensure all existing incidents have an investigation parent and typed incident link.
INSERT INTO investigations (
  investigation_id, investigation_type, title, description, status, severity, provenance, source_description
)
SELECT
  'INV-' || i.incident_id,
  'NEW_DISRUPTION',
  COALESCE(NULLIF(i.description,''), i.incident_type),
  i.description,
  CASE WHEN UPPER(i.status) IN ('CLOSED','RESOLVED') THEN 'CLOSED' ELSE 'READY_TO_START' END,
  CASE WHEN UPPER(i.severity) IN ('LOW','MEDIUM','HIGH','CRITICAL') THEN UPPER(i.severity) END,
  CASE WHEN UPPER(i.provenance) IN ('LIVE','SYNTHETIC_DEMO','SIMULATED','PUBLIC_SOURCE','UNKNOWN') THEN UPPER(i.provenance) ELSE 'SYNTHETIC_DEMO' END,
  jsonb_build_object('seed_origin','v2.3 incident seed')
FROM incidents i
ON CONFLICT (investigation_id) DO NOTHING;

INSERT INTO investigation_incidents(investigation_id, incident_id)
SELECT 'INV-' || incident_id, incident_id FROM incidents
ON CONFLICT DO NOTHING;

-- SCX-04 flagship association; no new operational values are fabricated.
INSERT INTO investigation_scenarios(investigation_id, scenario_id)
SELECT 'INV-' || linked_incident_id, scenario_id
FROM scenario_definitions
WHERE scenario_id='SCX-04' AND linked_incident_id='INC-2026-001'
ON CONFLICT DO NOTHING;

-- The flagship PO and shipment are linked from existing incident_entities.
INSERT INTO investigation_purchase_orders(investigation_id, po_id)
SELECT 'INV-INC-2026-001', 'PO-1007'
WHERE EXISTS (SELECT 1 FROM purchase_orders WHERE po_id='PO-1007')
ON CONFLICT DO NOTHING;

INSERT INTO investigation_shipments(investigation_id, shipment_id)
SELECT 'INV-INC-2026-001', 'SHIP-209'
WHERE EXISTS (SELECT 1 FROM shipments WHERE shipment_id='SHIP-209')
ON CONFLICT DO NOTHING;
