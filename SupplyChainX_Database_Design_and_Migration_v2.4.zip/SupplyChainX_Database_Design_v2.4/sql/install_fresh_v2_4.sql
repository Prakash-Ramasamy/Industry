-- Run with psql from package root.
\set ON_ERROR_STOP on
\i sql/schema.sql
\i sql/load_all.sql
\i sql/migrate_v2_3_to_v2_4.sql
\i sql/seed_v2_4.sql
\i sql/views_v2_4.sql
\i sql/validation_v2_4.sql
