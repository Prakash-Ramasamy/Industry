-- Optional read models for frontend/API.
SET search_path TO scx, public;

CREATE OR REPLACE VIEW v_investigation_summary AS
SELECT
  inv.investigation_id,
  inv.investigation_type,
  inv.title,
  inv.status,
  inv.severity,
  inv.provenance,
  inv.created_at,
  inv.updated_at,
  COUNT(DISTINCT ii.incident_id) AS linked_incident_count,
  COUNT(DISTINCT ipo.po_id) AS linked_purchase_order_count,
  COUNT(DISTINCT ish.shipment_id) AS linked_shipment_count,
  COUNT(DISTINCT wr.workflow_run_id) AS workflow_run_count,
  COUNT(DISTINCT rp.plan_id) AS recovery_plan_count
FROM investigations inv
LEFT JOIN investigation_incidents ii ON ii.investigation_id=inv.investigation_id
LEFT JOIN investigation_purchase_orders ipo ON ipo.investigation_id=inv.investigation_id
LEFT JOIN investigation_shipments ish ON ish.investigation_id=inv.investigation_id
LEFT JOIN workflow_runs wr ON wr.investigation_id=inv.investigation_id
LEFT JOIN recovery_plans rp ON rp.investigation_id=inv.investigation_id
GROUP BY inv.investigation_id;

CREATE OR REPLACE VIEW v_investigation_workflow_latest AS
SELECT DISTINCT ON (wr.investigation_id)
  wr.investigation_id, wr.workflow_run_id, wr.run_status,
  wr.current_stage_number, wr.current_stage_key,
  wr.overall_progress_percent, wr.waiting_for_human,
  wr.started_at, wr.completed_at, wr.last_event_at
FROM workflow_runs wr
ORDER BY wr.investigation_id, wr.started_at DESC;
