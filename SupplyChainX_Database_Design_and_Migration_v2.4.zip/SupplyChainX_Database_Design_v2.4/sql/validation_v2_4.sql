-- SupplyChain X v2.4 validation checks.
SET search_path TO scx, public;

-- 1. Every actual incident must have a parent investigation.
SELECT i.incident_id
FROM incidents i
LEFT JOIN investigation_incidents ii ON ii.incident_id=i.incident_id
LEFT JOIN investigations inv ON inv.investigation_id=ii.investigation_id
WHERE inv.investigation_id IS NULL;

-- 2. Every workflow run must belong to an investigation.
SELECT workflow_run_id FROM workflow_runs WHERE investigation_id IS NULL;

-- 3. Every recovery plan must belong to an investigation.
SELECT plan_id FROM recovery_plans WHERE investigation_id IS NULL;

-- 4. No investigation may have an invalid type/status.
SELECT investigation_id, investigation_type, status
FROM investigations
WHERE investigation_type NOT IN ('NEW_DISRUPTION','EXISTING_ORDER','EXISTING_SHIPMENT','PROACTIVE_SCENARIO')
   OR status NOT IN ('DRAFT','IDENTIFYING_ENTITIES','READY_TO_START','IN_PROGRESS',
                     'AWAITING_APPROVAL','CHANGES_REQUESTED','SIMULATED','CLOSED','FAILED','CANCELLED');

-- 5. Typed source links must resolve.
SELECT i.investigation_id, i.po_id
FROM investigation_purchase_orders i
LEFT JOIN purchase_orders p ON p.po_id=i.po_id
WHERE p.po_id IS NULL;

SELECT i.investigation_id, i.shipment_id
FROM investigation_shipments i
LEFT JOIN shipments s ON s.shipment_id=i.shipment_id
WHERE s.shipment_id IS NULL;

-- 6. Flagship linkage must remain intact.
SELECT inv.investigation_id, ii.incident_id, ipo.po_id, ish.shipment_id, isc.scenario_id
FROM investigations inv
LEFT JOIN investigation_incidents ii ON ii.investigation_id=inv.investigation_id
LEFT JOIN investigation_purchase_orders ipo ON ipo.investigation_id=inv.investigation_id
LEFT JOIN investigation_shipments ish ON ish.investigation_id=inv.investigation_id
LEFT JOIN investigation_scenarios isc ON isc.investigation_id=inv.investigation_id
WHERE inv.investigation_id='INV-INC-2026-001';

-- 7. Existing shipment quantity quality gates (must be reviewed independently).
SELECT sh.po_line_id, pol.ordered_qty, SUM(si.quantity) AS total_shipped_qty
FROM shipments sh
JOIN shipment_items si ON si.shipment_id=sh.shipment_id
JOIN purchase_order_lines pol ON pol.po_line_id=sh.po_line_id
GROUP BY sh.po_line_id, pol.ordered_qty
HAVING SUM(si.quantity) > pol.ordered_qty;

-- 8. Summary counts.
SELECT 'investigations' AS table_name, COUNT(*) AS row_count FROM investigations
UNION ALL SELECT 'investigation_incidents', COUNT(*) FROM investigation_incidents
UNION ALL SELECT 'investigation_purchase_orders', COUNT(*) FROM investigation_purchase_orders
UNION ALL SELECT 'investigation_shipments', COUNT(*) FROM investigation_shipments
UNION ALL SELECT 'investigation_scenarios', COUNT(*) FROM investigation_scenarios
UNION ALL SELECT 'scenario_runs', COUNT(*) FROM scenario_runs
ORDER BY table_name;
