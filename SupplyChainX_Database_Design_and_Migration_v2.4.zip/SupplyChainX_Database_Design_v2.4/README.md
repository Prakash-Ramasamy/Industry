# SupplyChain X – Expanded synthetic PostgreSQL seed pack

All company-specific records are synthetic demo data. Do not represent these records as real suppliers, customers, shipments, routes, inventory or projects.

## Contents
- `sql/schema.sql`: PostgreSQL schema, foreign keys, checks and indexes.
- `data/*.csv`: CSV seed data.
- `sql/seed.sql`: psql client-side `\\copy` loader.
- `scripts/load_seed_data.py`: psycopg 3 bulk CSV loader.
- `sql/validation.sql`: row counts, incident trace and assertions.
- `DATASET_MANIFEST.json`: provenance and record counts.

## Azure Database for PostgreSQL
Create an Azure Database for PostgreSQL Flexible Server, configure firewall/private networking, TLS, and a least-privilege database user. Set:
`DATABASE_URL='postgresql://USER:PASSWORD@HOST:5432/DATABASE?sslmode=require'`
Use a secret store/environment variable; do not commit credentials.

## Load
From this extracted directory:
1. `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/schema.sql`
2. Option A: `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/seed.sql`
   (run from pack root; `data/*.csv` paths are relative to current directory)
3. Option B: `pip install -r requirements.txt && python scripts/load_seed_data.py`
4. Validate: `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/validation.sql`

`python scripts/load_seed_data.py --truncate` destructively truncates all seed tables. Use only on a dedicated empty demo database.

## Seed order
Reference/master records → supplier capability and qualifications → routes → projects → purchase orders → shipments → inventory → incidents/evidence. Recovery workflow tables are intentionally empty; runtime workflow creates plans, actions, validations, approvals, simulations and agent-run records.

## Connected demonstration scenario INC-2026-001
SUP-014 disrupted for 21 days; BAT-MOD-480; PO-1007 for 600 units; SHIP-209 with 250 units; PORT-07 congested; WAREHOUSE-03 has 220 on hand and 70 reserved (150 available); PRJ-SOLARWIND-02; milestone MS-04; candidate suppliers SUP-022 and SUP-031; candidate port PORT-11.

`incident_entities.entity_id` is polymorphic and cannot reference multiple entity tables with a normal FK. The operational tables have real foreign keys. Validate polymorphic links in application code or use typed link tables in production.


## v2.3 extended schema (recommended)
The `sql/schema.sql` now includes the original 29 operational seed tables plus extended v2.3 tables for:
- 8 industry workspaces and SCX-01..SCX-08 scenario registry (SCX-04 flagship)
- facilities, supplier-facility links, materials, component BOM and industry mappings
- trade events, evidence source register and evidence verification
- typed incident links, impact snapshots and dependency graph snapshots
- durable workflow runs, nine workflow stages, stage-4 parallel lanes and workflow events
- seven agent definitions, reproducibility metadata and structured outputs
- supplier/logistics/risk assessments
- plan versioning, validation findings and review acknowledgements
- simulation metrics, audit enhancements, roles, ingestion lineage, data quality and idempotency

## Load complete v2.3 database
Run from the extracted package root:
1. `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/schema.sql`
2. `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/load_all.sql`
3. `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/validation.sql`

`load_all.sql` loads the existing CSV data and then adds the v2.3 reference/configuration seed rows.
The schema and seed scripts have been generated but have NOT been executed against your Azure server. Run first on a fresh development database and review any errors before production use.

## Canonical flagship data
The existing CSV seed is the source of truth for operational quantities and dates. For INC-2026-001 it contains PO-1007 / BAT-MOD-480 / 600 units, SHIP-209 / 250 units, WAREHOUSE-03 inventory 220 on hand and 70 reserved (150 available), and MS-04. Existing supplier capability rows show SUP-022 capacity 400 and SUP-031 capacity 300, with the CSV lead-time values. These should be used by the backend; do not replace them with illustrative values from a UI mock fixture.

## Important data model note
`incident_entities` and `entity_evidence` preserve flexible entity links for the synthetic import. The v2.3 schema adds typed incident link tables with real foreign keys for supplier, component, project and shipment relationships. Use typed links for new production-grade application logic; validate legacy polymorphic links in application code. The same principle applies to `trade_event_entities` until typed impact bridge tables are added.


Canonical fixture: `fixtures/scx-04-canonical.json` is generated from the database CSV seed records and supersedes earlier UI-only illustrative fixture values. The seed dataset does not supply a recovery budget, complete plan cost model, CO2e or verified coordinates; these remain NULL/unknown until a documented source or deterministic model supplies them.


# v2.4 – Investigation parent model (Option A)

v2.4 preserves the v2.3 operational data model and adds an `investigations` parent entity. `incidents` continues to mean an actual disruption; it is not generalized into a catch-all case table.

## New tables
- `investigations`: parent business work item for all four types: `NEW_DISRUPTION`, `EXISTING_ORDER`, `EXISTING_SHIPMENT`, `PROACTIVE_SCENARIO`.
- `investigation_incidents`: typed FK link to actual incident records.
- `investigation_purchase_orders`: typed FK link to existing PO records.
- `investigation_shipments`: typed FK link to existing shipment records.
- `investigation_scenarios`: link to reusable scenario definitions.
- `investigation_entity_links`: discovery/confirmation metadata for supplier, component, port, warehouse, carrier, PO line, project, milestone, route, trade event, etc. Its `entity_id` is polymorphic; application-level validation is required.
- `investigation_evidence`: typed FK link to evidence records.
- `scenario_runs`: per-investigation execution snapshot for proactive scenario previews.

## Migration from v2.3
Run the v2.3 schema and complete v2.3 seed first, then run:

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/migrate_v2_3_to_v2_4.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/seed_v2_4.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/views_v2_4.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/validation_v2_4.sql
```

Run on a fresh development copy first. Back up the database before migrating. The migration backfills one `INV-<incident_id>` investigation for each existing incident, links existing incident entity references, and preserves existing incident IDs and operational data.

## Fresh development install
From this package root, run:

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/schema.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/load_all.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/migrate_v2_3_to_v2_4.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/seed_v2_4.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/views_v2_4.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/validation_v2_4.sql
```

`schema.sql` and `load_all.sql` remain the v2.3 operational baseline; the v2.4 migration is applied after seed data so it can backfill parent investigations from actual incident rows.

## Existing incident / SCX-04 backfill
The migration creates `INV-INC-2026-001` for the flagship `INC-2026-001`, retains `SCX-04`, and links the existing PO-1007 and SHIP-209 where those seed rows exist. It does not create new operational PO, shipment, supplier, inventory or project rows.

## Existing order and shipment investigations
Create an `investigations` row with type `EXISTING_ORDER` or `EXISTING_SHIPMENT`, then insert the existing `po_id` into `investigation_purchase_orders` or `shipment_id` into `investigation_shipments`. Do not duplicate or alter the source business transaction merely to investigate it.

## Proactive scenarios
Create an investigation with type `PROACTIVE_SCENARIO`, then create a `scenario_runs` row containing the validated scenario inputs and source snapshot. Mark outputs as simulated/not executed. Do not create an `incidents` row for a hypothetical event unless a real disruption is subsequently confirmed and explicitly recorded.

## Compatibility
`workflow_runs`, `agent_runs`, `recovery_plans`, supplier/logistics/risk assessments gain a mandatory `investigation_id` after existing rows are backfilled. Their legacy `incident_id` columns are retained but made nullable where required, allowing order/shipment/scenario investigations that have no actual incident. Existing APIs that only accept incident IDs should be migrated to investigation IDs before enabling non-incident workflows.

## Validation caveat
`validation_v2_4.sql` reports any remaining aggregate PO-line shipment over-fulfilment as a data-quality result. It does not automatically change quantities. Resolve the previously identified 38 shipment rows using a reviewed correction plan before using aggregate fulfilment metrics. The migration does not silently cap or rewrite those quantities.

## Execution status
This package contains generated SQL and documentation. It has NOT been executed against the user's Azure Database for PostgreSQL server. Successful migration and data validation must be confirmed by running the scripts in the user's development database.
