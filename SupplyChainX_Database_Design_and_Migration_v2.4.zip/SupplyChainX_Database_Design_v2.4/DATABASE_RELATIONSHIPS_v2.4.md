# SupplyChain X v2.4 – Relationship design

```mermaid
erDiagram
  INVESTIGATIONS ||--o{ INVESTIGATION_INCIDENTS : links
  INCIDENTS ||--o{ INVESTIGATION_INCIDENTS : relates
  INVESTIGATIONS ||--o{ INVESTIGATION_PURCHASE_ORDERS : links
  PURCHASE_ORDERS ||--o{ INVESTIGATION_PURCHASE_ORDERS : relates
  INVESTIGATIONS ||--o{ INVESTIGATION_SHIPMENTS : links
  SHIPMENTS ||--o{ INVESTIGATION_SHIPMENTS : relates
  INVESTIGATIONS ||--o{ INVESTIGATION_SCENARIOS : uses
  SCENARIO_DEFINITIONS ||--o{ INVESTIGATION_SCENARIOS : defines
  INVESTIGATIONS ||--o{ INVESTIGATION_ENTITY_LINKS : discovers
  INVESTIGATIONS ||--o{ INVESTIGATION_EVIDENCE : supported_by
  EVIDENCE_RECORDS ||--o{ INVESTIGATION_EVIDENCE : supports
  INVESTIGATIONS ||--o{ WORKFLOW_RUNS : executes
  WORKFLOW_RUNS ||--o{ WORKFLOW_STAGES : contains
  WORKFLOW_RUNS ||--o{ AGENT_RUNS : invokes
  INVESTIGATIONS ||--o{ RECOVERY_PLANS : proposes
  RECOVERY_PLANS ||--o{ RECOVERY_ACTIONS : contains
  RECOVERY_PLANS ||--o{ PLAN_VALIDATION_RUNS : validates
  RECOVERY_PLANS ||--o{ PLAN_APPROVALS : approved_by
  RECOVERY_PLANS ||--o{ SIMULATION_RUNS : simulates
  INVESTIGATIONS ||--o| SCENARIO_RUNS : previews
```

## Relationship rules

1. `investigations` is the parent business work item for every investigation.
2. `incidents` remains the record of an actual disruption. An investigation may link to zero, one, or multiple incidents.
3. Existing orders and shipments are linked through typed bridge tables with real foreign keys. The underlying PO and shipment rows are never duplicated.
4. `investigation_entity_links` stores discovery/confirmation metadata for multiple entity types. Its `entity_id` is polymorphic and therefore must be validated by application logic; use typed bridge tables for important source records.
5. Workflow runs, agent runs, assessments, recovery plans, simulations and audit events are scoped to an investigation. `incident_id` is retained as a nullable compatibility/reference field where it existed.
6. Proactive scenario inputs and outputs are stored in `scenario_runs`; `scenario_definitions` remains the reusable scenario catalogue.
7. A scenario preview is not an actual incident and does not modify operational PO, shipment, inventory or supplier records.
