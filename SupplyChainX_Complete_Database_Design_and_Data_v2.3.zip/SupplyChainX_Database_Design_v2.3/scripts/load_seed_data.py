#!/usr/bin/env python3
import argparse, csv, os, pathlib, sys
import psycopg
ROOT=pathlib.Path(__file__).resolve().parents[1]
ORDER=['countries', 'suppliers', 'components', 'ports', 'warehouses', 'carriers', 'supplier_components', 'supplier_qualifications', 'supplier_certifications', 'supplier_capacity_snapshots', 'routes', 'route_port_stops', 'projects', 'project_component_requirements', 'project_milestones', 'milestone_component_requirements', 'purchase_orders', 'purchase_order_lines', 'shipments', 'shipment_items', 'inventory_snapshots', 'inventory_reservations', 'inventory_movements', 'port_status_snapshots', 'incidents', 'incident_entities', 'incident_events', 'evidence_records', 'entity_evidence']
p=argparse.ArgumentParser()
p.add_argument("--truncate",action="store_true")
a=p.parse_args()
dsn=os.environ.get("DATABASE_URL")
if not dsn: sys.exit("Set DATABASE_URL first.")
with psycopg.connect(dsn,autocommit=False) as conn:
  with conn.cursor() as cur:
    cur.execute("SET search_path TO scx, public")
    if a.truncate: cur.execute("TRUNCATE "+", ".join("scx."+t for t in reversed(ORDER))+" CASCADE")
    for table in ORDER:
      path=ROOT/"data"/(table+".csv")
      with path.open(encoding="utf-8",newline="") as f:
        rd=csv.reader(f); cols=next(rd)
        with cur.copy(f"COPY scx.{table} ({', '.join(cols)}) FROM STDIN") as cp:
          for row in rd: cp.write_row(row)
      print("Loaded",table)
  conn.commit()
print("Seed load complete.")
