SET search_path TO scx,public;
SELECT 'suppliers' table_name,count(*) row_count FROM suppliers
UNION ALL SELECT 'components',count(*) FROM components
UNION ALL SELECT 'purchase_orders',count(*) FROM purchase_orders
UNION ALL SELECT 'shipments',count(*) FROM shipments
UNION ALL SELECT 'projects',count(*) FROM projects
UNION ALL SELECT 'incidents',count(*) FROM incidents;
SELECT s.supplier_id,c.component_id,po.po_id,sh.shipment_id,sh.origin_port_id,
       inv.on_hand_qty,inv.reserved_qty,inv.on_hand_qty-inv.reserved_qty available_qty,
       pr.project_id,pm.milestone_id
FROM suppliers s JOIN purchase_orders po ON po.supplier_id=s.supplier_id
JOIN purchase_order_lines pol ON pol.po_id=po.po_id
JOIN components c ON c.component_id=pol.component_id
JOIN shipments sh ON sh.po_line_id=pol.po_line_id
JOIN inventory_snapshots inv ON inv.warehouse_id='WAREHOUSE-03' AND inv.component_id=c.component_id
JOIN projects pr ON pr.project_id='PRJ-SOLARWIND-02'
JOIN project_milestones pm ON pm.project_id=pr.project_id AND pm.milestone_id='MS-04'
WHERE s.supplier_id='SUP-014' AND c.component_id='BAT-MOD-480' AND po.po_id='PO-1007' AND sh.shipment_id='SHIP-209' AND sh.origin_port_id='PORT-07';
SELECT EXISTS(SELECT 1 FROM suppliers WHERE supplier_id='SUP-014' AND status='DISRUPTED') supplier_disrupted,
EXISTS(SELECT 1 FROM components WHERE component_id='BAT-MOD-480') component_exists,
EXISTS(SELECT 1 FROM purchase_orders WHERE po_id='PO-1007' AND supplier_id='SUP-014') po_connected,
EXISTS(SELECT 1 FROM shipments WHERE shipment_id='SHIP-209' AND po_line_id='POL-1007-01') shipment_connected,
EXISTS(SELECT 1 FROM ports WHERE port_id='PORT-07' AND status='CONGESTED') port_congested,
EXISTS(SELECT 1 FROM inventory_snapshots WHERE warehouse_id='WAREHOUSE-03' AND component_id='BAT-MOD-480' AND on_hand_qty=220 AND reserved_qty=70) inventory_seeded,
EXISTS(SELECT 1 FROM project_milestones WHERE milestone_id='MS-04' AND project_id='PRJ-SOLARWIND-02') milestone_connected;
SELECT count(*) invalid_inventory FROM inventory_snapshots WHERE reserved_qty>on_hand_qty;
SELECT count(*) invalid_po_lines FROM purchase_order_lines WHERE received_qty>ordered_qty;
