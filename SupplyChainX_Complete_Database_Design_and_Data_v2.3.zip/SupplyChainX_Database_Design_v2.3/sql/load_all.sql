-- Run from package root with psql; schema must be applied first.
\i sql/seed.sql
\i sql/seed_extension.sql
ANALYZE;
