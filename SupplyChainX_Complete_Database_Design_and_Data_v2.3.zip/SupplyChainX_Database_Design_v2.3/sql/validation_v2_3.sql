
SET search_path TO scx, public;
SELECT 'industries' AS table_name, COUNT(*) AS rows FROM industries
UNION ALL SELECT 'scenario_definitions', COUNT(*) FROM scenario_definitions
UNION ALL SELECT 'agent_definitions', COUNT(*) FROM agent_definitions
UNION ALL SELECT 'workflow_runs', COUNT(*) FROM workflow_runs
UNION ALL SELECT 'recovery_plans', COUNT(*) FROM recovery_plans
ORDER BY table_name;

-- Canonical flagship trace
SELECT i.incident_id, i.scenario_id, i.title, i.industry_id,
       s.supplier_name AS disrupted_supplier,
       c.component_name,
       po.po_id, pol.ordered_qty, sh.shipment_id,
       w.warehouse_name, inv.on_hand_qty, inv.reserved_qty,
       (inv.on_hand_qty-inv.reserved_qty) AS available_qty,
       p.project_name, pm.milestone_id, pm.milestone_name
FROM incidents i
JOIN incident_supplier_links isl ON isl.incident_id=i.incident_id AND isl.link_role='DISRUPTED_SUPPLIER'
JOIN suppliers s ON s.supplier_id=isl.supplier_id
JOIN incident_component_links icl ON icl.incident_id=i.incident_id AND icl.link_role='AFFECTED_COMPONENT'
JOIN components c ON c.component_id=icl.component_id
JOIN purchase_orders po ON po.po_id='PO-1007'
JOIN purchase_order_lines pol ON pol.po_id=po.po_id AND pol.component_id=c.component_id
JOIN shipments sh ON sh.shipment_id='SHIP-209'
JOIN inventory_snapshots inv ON inv.warehouse_id='WAREHOUSE-03' AND inv.component_id=c.component_id
JOIN warehouses w ON w.warehouse_id=inv.warehouse_id
JOIN incident_project_links ip ON ip.incident_id=i.incident_id
JOIN projects p ON p.project_id=ip.project_id
JOIN project_milestones pm ON pm.project_id=p.project_id AND pm.milestone_id='MS-04'
WHERE i.incident_id='INC-2026-001';

-- Guard checks: these must return zero rows.
SELECT 'scenario_mismatch' AS check_name, scenario_id
FROM scenario_definitions
WHERE (scenario_id='SCX-04' AND (industry_id<>'RENEWABLE_ENERGY' OR linked_incident_id<>'INC-2026-001' OR NOT is_flagship));
SELECT 'available_inventory_negative' AS check_name, inventory_snapshot_id
FROM inventory_snapshots WHERE on_hand_qty < reserved_qty;
SELECT 'shipment_qty_exceeds_order_line' AS check_name, sh.shipment_id
FROM shipments sh
JOIN shipment_items si ON si.shipment_id=sh.shipment_id
JOIN purchase_order_lines pol ON pol.po_line_id=sh.po_line_id
WHERE si.quantity > pol.ordered_qty;
