\set ON_ERROR_STOP on
\i sql/schema.sql
\i sql/load_all.sql
\i sql/validation.sql
\i sql/validation_v2_3.sql
