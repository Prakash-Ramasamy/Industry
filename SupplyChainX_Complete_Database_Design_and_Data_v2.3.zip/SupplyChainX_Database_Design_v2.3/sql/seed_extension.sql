
SET search_path TO scx, public;
INSERT INTO industries(industry_id,industry_name,description) VALUES
('RENEWABLE_ENERGY','Renewable Energy (Solar + Wind + BESS)','Project developer and portfolio view across renewable generation and storage'),
('SOLAR_ENERGY','Solar Energy','Photovoltaic manufacturing supply chain'),
('SEMICONDUCTORS_ELECTRONICS','Semiconductors & Electronics','Semiconductor and electronics manufacturing supply chain'),
('EV_BATTERIES','EV & Batteries','Vehicle battery manufacturing supply chain'),
('AUTOMOTIVE','Automotive','Automotive OEM and tiered supplier supply chain'),
('PHARMACEUTICALS','Pharmaceuticals','API, excipient and finished medicine supply chain'),
('AEROSPACE','Aerospace','Certified aerospace component supply chain'),
('INDUSTRIAL_MACHINERY','Industrial Machinery','Industrial equipment, motor and bearing supply chain')
ON CONFLICT (industry_id) DO NOTHING;

INSERT INTO scenario_definitions(scenario_id,industry_id,scenario_name,hypothetical_event,scenario_status,linked_incident_id,is_flagship) VALUES
('SCX-01','SOLAR_ENERGY','Solar module supplier disruption','Solar module supplier disruption','MOCK',NULL,FALSE),
('SCX-02','SEMICONDUCTORS_ELECTRONICS','Chip fabrication disruption','Chip fabrication disruption / export control','MOCK',NULL,FALSE),
('SCX-03','EV_BATTERIES','Critical mineral export restriction','Critical mineral export restriction','MOCK',NULL,FALSE),
('SCX-04','RENEWABLE_ENERGY','BESS battery supplier outage','Battery supplier outage: INC-2026-001','FLAGSHIP_BACKEND_CONNECTED','INC-2026-001',TRUE),
('SCX-05','AUTOMOTIVE','Automotive component shortage','Automotive component shortage','MOCK',NULL,FALSE),
('SCX-06','PHARMACEUTICALS','API supply disruption','API supply disruption','MOCK',NULL,FALSE),
('SCX-07','AEROSPACE','Certified component supply disruption','Certified component supply disruption','MOCK',NULL,FALSE),
('SCX-08','INDUSTRIAL_MACHINERY','Motor and bearing supplier outage','Motor and bearing supplier outage','MOCK',NULL,FALSE)
ON CONFLICT (scenario_id) DO UPDATE SET industry_id=EXCLUDED.industry_id,scenario_name=EXCLUDED.scenario_name,
 hypothetical_event=EXCLUDED.hypothetical_event,scenario_status=EXCLUDED.scenario_status,
 linked_incident_id=EXCLUDED.linked_incident_id,is_flagship=EXCLUDED.is_flagship;

INSERT INTO agent_definitions(agent_id,agent_name,purpose,prompt_version,model_deployment,output_schema_version) VALUES
('SCX-Impact-Investigator','Impact Investigator','Trace affected multi-tier entities and project dependencies','1.0','CONFIGURE_IN_ENV','1.0'),
('SCX-Supplier-Assessor','Supplier Assessor','Assess supplier qualification, exact specification and capacity','1.0','CONFIGURE_IN_ENV','1.0'),
('SCX-Logistics-Assessor','Logistics Assessor','Assess route, port, carrier and transit feasibility','1.0','CONFIGURE_IN_ENV','1.0'),
('SCX-Risk-Assessor','Risk Assessor','Assess concentration, country, material and disruption risk','1.0','CONFIGURE_IN_ENV','1.0'),
('SCX-Recovery-Planner','Recovery Planner','Propose structured recovery action candidates without arithmetic','1.0','CONFIGURE_IN_ENV','1.0'),
('SCX-Plan-Assurance','Plan Assurance','Explain deterministic validation results; cannot override them','1.0','CONFIGURE_IN_ENV','1.0'),
('SCX-Executive-Explainer','Executive Explainer','Explain approved plan and deterministic simulation outcome','1.0','CONFIGURE_IN_ENV','1.0')
ON CONFLICT (agent_id) DO NOTHING;

INSERT INTO app_roles(role_id,role_name,description) VALUES
('ROLE_ANALYST','Analyst','Investigate incidents and prepare recovery plans'),
('ROLE_APPROVER','Approver','Review and approve eligible recovery plans'),
('ROLE_EXECUTIVE','Executive','Read executive summaries and portfolio views'),
('ROLE_ADMIN','Administrator','Manage configuration and access')
ON CONFLICT (role_id) DO NOTHING;

-- Bind existing flagship entities with typed foreign keys.
INSERT INTO incident_supplier_links(incident_id,supplier_id,link_role) VALUES
('INC-2026-001','SUP-014','DISRUPTED_SUPPLIER'),
('INC-2026-001','SUP-022','ALTERNATIVE_SUPPLIER'),
('INC-2026-001','SUP-031','ALTERNATIVE_SUPPLIER')
ON CONFLICT DO NOTHING;
INSERT INTO incident_component_links(incident_id,component_id,link_role) VALUES
('INC-2026-001','BAT-MOD-480','AFFECTED_COMPONENT')
ON CONFLICT DO NOTHING;
INSERT INTO incident_project_links(incident_id,project_id,link_role) VALUES
('INC-2026-001','PRJ-SOLARWIND-02','AFFECTED_PROJECT')
ON CONFLICT DO NOTHING;
INSERT INTO incident_shipment_links(incident_id,shipment_id,link_role) VALUES
('INC-2026-001','SHIP-209','AFFECTED_SHIPMENT')
ON CONFLICT DO NOTHING;

-- Minimal source register for synthetic demo evidence.
INSERT INTO evidence_sources(source_id,source_name,publisher,source_type,trust_tier,license_or_terms)
VALUES
('SRC-SYNTHETIC','SupplyChain X Synthetic Demo Generator','SupplyChain X demo','SYNTHETIC_FIXTURE','DEMO_ONLY','Synthetic internal demo data; not external evidence')
ON CONFLICT (source_id) DO NOTHING;

-- Map all existing evidence records to the synthetic source.
INSERT INTO evidence_record_sources(evidence_id,source_id,citation_text)
SELECT evidence_id,'SRC-SYNTHETIC','Generated synthetic demo evidence record'
FROM evidence_records
ON CONFLICT DO NOTHING;

-- Add industries to the flagship project and core component.
INSERT INTO project_industries(project_id,industry_id)
VALUES ('PRJ-SOLARWIND-02','RENEWABLE_ENERGY')
ON CONFLICT DO NOTHING;
INSERT INTO industry_components(component_id,industry_id)
VALUES ('BAT-MOD-480','RENEWABLE_ENERGY'),('BAT-MOD-480','EV_BATTERIES')
ON CONFLICT DO NOTHING;
INSERT INTO industry_suppliers(supplier_id,industry_id)
VALUES ('SUP-014','RENEWABLE_ENERGY'),('SUP-022','RENEWABLE_ENERGY'),('SUP-031','RENEWABLE_ENERGY')
ON CONFLICT DO NOTHING;

-- Mark the incident with the canonical scenario and industry metadata.
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS scenario_id TEXT;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS title TEXT;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS industry_id TEXT;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS started_at TIMESTAMPTZ;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS classification TEXT NOT NULL DEFAULT 'SYNTHETIC_DEMO';
UPDATE incidents SET scenario_id='SCX-04', title='Battery supplier outage affecting BESS commissioning',
 industry_id='RENEWABLE_ENERGY', started_at=(start_date::timestamp AT TIME ZONE 'UTC')
WHERE incident_id='INC-2026-001';

-- Typed graph link to source entities is preserved in incident_*_links.
