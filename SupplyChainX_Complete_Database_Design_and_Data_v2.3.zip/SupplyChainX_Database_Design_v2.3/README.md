# SupplyChain X – Expanded synthetic PostgreSQL seed pack

All company-specific records are synthetic demo data. Do not represent these records as real suppliers, customers, shipments, routes, inventory or projects.

## Contents
- `sql/schema.sql`: PostgreSQL schema, foreign keys, checks and indexes.
- `data/*.csv`: CSV seed data.
- `sql/seed.sql`: psql client-side `\\copy` loader.
- `scripts/load_seed_data.py`: psycopg 3 bulk CSV loader.
- `sql/validation.sql`: row counts, incident trace and assertions.
- `DATASET_MANIFEST.json`: provenance and record counts.

## Azure Database for PostgreSQL
Create an Azure Database for PostgreSQL Flexible Server, configure firewall/private networking, TLS, and a least-privilege database user. Set:
`DATABASE_URL='postgresql://USER:PASSWORD@HOST:5432/DATABASE?sslmode=require'`
Use a secret store/environment variable; do not commit credentials.

## Load
From this extracted directory:
1. `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/schema.sql`
2. Option A: `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/seed.sql`
   (run from pack root; `data/*.csv` paths are relative to current directory)
3. Option B: `pip install -r requirements.txt && python scripts/load_seed_data.py`
4. Validate: `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/validation.sql`

`python scripts/load_seed_data.py --truncate` destructively truncates all seed tables. Use only on a dedicated empty demo database.

## Seed order
Reference/master records → supplier capability and qualifications → routes → projects → purchase orders → shipments → inventory → incidents/evidence. Recovery workflow tables are intentionally empty; runtime workflow creates plans, actions, validations, approvals, simulations and agent-run records.

## Connected demonstration scenario INC-2026-001
SUP-014 disrupted for 21 days; BAT-MOD-480; PO-1007 for 600 units; SHIP-209 with 250 units; PORT-07 congested; WAREHOUSE-03 has 220 on hand and 70 reserved (150 available); PRJ-SOLARWIND-02; milestone MS-04; candidate suppliers SUP-022 and SUP-031; candidate port PORT-11.

`incident_entities.entity_id` is polymorphic and cannot reference multiple entity tables with a normal FK. The operational tables have real foreign keys. Validate polymorphic links in application code or use typed link tables in production.


## v2.3 extended schema (recommended)
The `sql/schema.sql` now includes the original 29 operational seed tables plus extended v2.3 tables for:
- 8 industry workspaces and SCX-01..SCX-08 scenario registry (SCX-04 flagship)
- facilities, supplier-facility links, materials, component BOM and industry mappings
- trade events, evidence source register and evidence verification
- typed incident links, impact snapshots and dependency graph snapshots
- durable workflow runs, nine workflow stages, stage-4 parallel lanes and workflow events
- seven agent definitions, reproducibility metadata and structured outputs
- supplier/logistics/risk assessments
- plan versioning, validation findings and review acknowledgements
- simulation metrics, audit enhancements, roles, ingestion lineage, data quality and idempotency

## Load complete v2.3 database
Run from the extracted package root:
1. `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/schema.sql`
2. `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/load_all.sql`
3. `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/validation.sql`

`load_all.sql` loads the existing CSV data and then adds the v2.3 reference/configuration seed rows.
The schema and seed scripts have been generated but have NOT been executed against your Azure server. Run first on a fresh development database and review any errors before production use.

## Canonical flagship data
The existing CSV seed is the source of truth for operational quantities and dates. For INC-2026-001 it contains PO-1007 / BAT-MOD-480 / 600 units, SHIP-209 / 250 units, WAREHOUSE-03 inventory 220 on hand and 70 reserved (150 available), and MS-04. Existing supplier capability rows show SUP-022 capacity 400 and SUP-031 capacity 300, with the CSV lead-time values. These should be used by the backend; do not replace them with illustrative values from a UI mock fixture.

## Important data model note
`incident_entities` and `entity_evidence` preserve flexible entity links for the synthetic import. The v2.3 schema adds typed incident link tables with real foreign keys for supplier, component, project and shipment relationships. Use typed links for new production-grade application logic; validate legacy polymorphic links in application code. The same principle applies to `trade_event_entities` until typed impact bridge tables are added.


Canonical fixture: `fixtures/scx-04-canonical.json` is generated from the database CSV seed records and supersedes earlier UI-only illustrative fixture values. The seed dataset does not supply a recovery budget, complete plan cost model, CO2e or verified coordinates; these remain NULL/unknown until a documented source or deterministic model supplies them.
